alert('Hello Content');
window.URL_CDN = chrome.runtime.getURL('content');
